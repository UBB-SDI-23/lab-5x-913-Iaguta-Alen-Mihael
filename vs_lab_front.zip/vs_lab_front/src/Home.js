import React,{Component} from 'react';

export class Home extends Component{

    render(){
        return(
            <div className="justify-content-center">
                <h1>Hello muhfuckas</h1>
                <p>This is my SDI chess project in my 4th semester.I wish you all Ramadan Kareem.</p>
            </div>
        )
    }
}