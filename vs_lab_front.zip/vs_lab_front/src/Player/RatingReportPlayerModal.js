import React, { Component } from 'react';
import { Modal, Button, Table } from 'react-bootstrap';

export class RatingReportPlayerModal extends Component {
    
  constructor(props) {
    super(props);
    this.state = { ratings: [] };
  }

  componentDidMount() {
    this.getRatings();
  }

  componentDidUpdate(){
    this.getRatings();
  }

  getRatings = () => {
    fetch(process.env.REACT_APP_API + 'chessplayers/ratings')
      .then((response) => response.json())
      .then((data) => {
        this.setState({ ratings: data });
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  render() {
    return (
      <Modal {...this.props} size='lg' aria-labelledby='contained-modal-title-vcenter' centered>
        <Modal.Header closeButton>
          <Modal.Title id='contained-modal-title-vcenter'>Player Ratings</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Name</th>
                <th>Rating</th>
              </tr>
            </thead>
            <tbody>
              {this.state.ratings.map((rating) => (
                <tr key={rating.id}>
                  <td>{rating.name}</td>
                  <td>{rating.rating}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </Modal.Body>
        <Modal.Footer>
          <Button variant='danger' onClick={this.props.onHide}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    );
  }
}